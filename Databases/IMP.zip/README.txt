Execute the scripts in the following order:

1) create_imp.sql
2) constraints_imp.sql
3) load_imp.sql

