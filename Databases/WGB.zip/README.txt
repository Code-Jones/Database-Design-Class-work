Execute the scripts in the following order:

1) create_wgb.sql
2) constraints_wgb.sql
3) load_wgb.sql

