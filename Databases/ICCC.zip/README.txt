Execute the scripts in the following order:

1. create_iccc.sql
2. constraints_iccc.sql
3. load_iccc.sql
4. updates_iccc.sql

