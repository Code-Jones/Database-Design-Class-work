Execute the scripts in the following order:

1. create_cpv.sql
2. constraints_cpv.sql
3. load_cpv.sql


